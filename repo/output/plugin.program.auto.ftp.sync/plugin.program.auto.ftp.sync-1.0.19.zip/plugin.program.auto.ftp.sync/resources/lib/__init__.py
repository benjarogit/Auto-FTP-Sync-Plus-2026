# -*- coding: utf-8 -*-
# resources.lib - Auto FTP Sync shared modules
